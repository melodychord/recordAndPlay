//
//  Waver.h
//  Waver
//
//  Created by kevinzhow on 14/12/14.
//  Copyright (c) 2014年 Catch Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^waverLevelCallback)(void);
@interface Waver : UIView


@property (nonatomic) CADisplayLink *displaylink;
@property (nonatomic) CGFloat normalizedValue;

@property (nonatomic, copy) void (^waverLevelCallback)(void);


@property (nonatomic) NSUInteger numberOfWaves;

@property (nonatomic) UIColor * waveColor;

@property (nonatomic) CGFloat level;

@property (nonatomic) CGFloat mainWaveWidth;

@property (nonatomic) CGFloat decorativeWavesWidth;

@property (nonatomic) CGFloat idleAmplitude;

@property (nonatomic) CGFloat frequency;

@property (nonatomic, readonly) CGFloat amplitude;

@property (nonatomic) CGFloat density;

@property (nonatomic) CGFloat phaseShift;

//

@property (nonatomic, readonly) NSMutableArray * waves;

@end
