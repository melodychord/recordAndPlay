//
//  ViewController.m
//  RecordAndPlayAudio
//
//  Created by Gavin on 2019/6/10.
//  Copyright © 2019年 Gavin. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "Waver.h"

@interface ViewController ()<AVAudioRecorderDelegate,AVAudioPlayerDelegate>

//录音管理器
@property (nonatomic,strong) AVAudioRecorder *audioRecorder;

//播放器
@property (nonatomic, strong) AVAudioPlayer *play;

//录音定时器
@property (nonatomic,strong) NSTimer *recordTimer;

//录音音量定时器
@property (nonatomic,strong) NSTimer *voiceTimer;

//录音时长
@property (nonatomic,assign) NSUInteger timeCount;

//录音存放的路径
@property (nonatomic,copy) NSString *Path;

//录音存放的URL
@property (nonatomic,strong) NSURL *url;

// 贝塞尔曲线 波纹
@property (nonatomic,strong) Waver *waver;

// 录音按钮
@property (nonatomic,strong) UIButton *recordButton;

// 停止按钮
@property (nonatomic,strong) UIButton *stopButton;

// 删除按钮
@property (nonatomic,strong) UIButton *deleteButton;

// 录音时长标签
@property (nonatomic,strong) UILabel *recordTimeLabel;

// 波纹图
@property (nonatomic,strong) UIView *rippleView;

// 播放按钮
@property (nonatomic,strong) UIButton *playButton;

// 播放云端按钮
@property (nonatomic,strong) UIButton *playOnlineButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.recordTimeLabel];
    [self.view addSubview:self.rippleView];
    [self.view addSubview:self.recordButton];
    [self.view addSubview:self.stopButton];
    [self.view addSubview:self.deleteButton];
    [self.view addSubview:self.playButton];
    [self.view addSubview:self.playOnlineButton];
    
    self.waver = [[Waver alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width,40)];
    self.waver.displaylink.paused = NO;
    self.waver.normalizedValue = 0;
    self.waver.frequency = 1.4;
    __weak Waver * weakWaver = self.waver;
    _waver.waverLevelCallback = ^{
        weakWaver.level = weakWaver.normalizedValue;
    };
    [self.rippleView addSubview:self.waver];
    
    
    //解决模拟器能录音 但真机不能录音 等问题
    AVAudioSession *recorder = [AVAudioSession sharedInstance];
    NSError *sessionError;
    [recorder setCategory:AVAudioSessionCategoryPlayAndRecord error:&sessionError];
    if(recorder == nil){
        NSLog(@"Error creating session:%@",[sessionError description]);
    }else{
        [recorder setActive:YES error:nil];
    }
    // Do any additional setup after loading the view, typically from a nib.
}

- (UILabel *)recordTimeLabel{
    if(!_recordTimeLabel){
        _recordTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width/2-30, 100, 160, 30)];
        _recordTimeLabel.textColor = [UIColor purpleColor];
        _recordTimeLabel.textAlignment = NSTextAlignmentLeft;
        _recordTimeLabel.text = @"00:00:00";
    }
    return _recordTimeLabel;
}

- (UIView *)rippleView{
    if(!_rippleView){
        _rippleView = [[UIView alloc] initWithFrame:CGRectMake(0, 150,[UIScreen mainScreen].bounds.size.width, 40)];
    }
    return _rippleView;
}

- (UIButton *)recordButton{
    if(!_recordButton){
        _recordButton = [[UIButton alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width/2-50, 220, 100, 30)];
        [_recordButton setTitle:@"开始录音" forState:UIControlStateNormal];
        [_recordButton setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        _recordButton.layer.borderWidth = 1.0;
        _recordButton.layer.borderColor = [UIColor purpleColor].CGColor;
        [_recordButton addTarget:self action:@selector(startRecord:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _recordButton;
}

- (UIButton *)stopButton{
    if(!_stopButton){
        _stopButton = [[UIButton alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width/2-50, 270, 100, 30)];
        [_stopButton setTitle:@"停止录音" forState:UIControlStateNormal];
        [_stopButton setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        _stopButton.layer.borderWidth = 1.0;
        _stopButton.layer.borderColor = [UIColor purpleColor].CGColor;
        [_stopButton addTarget:self action:@selector(stopRecord:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _stopButton;
}

- (UIButton *)deleteButton{
    if(!_deleteButton){
        _deleteButton = [[UIButton alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width/2-50, 320, 100, 30)];
        [_deleteButton setTitle:@"删除录音" forState:UIControlStateNormal];
        [_deleteButton setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        _deleteButton.layer.borderWidth = 1.0;
        _deleteButton.layer.borderColor = [UIColor purpleColor].CGColor;
        [_deleteButton addTarget:self action:@selector(deleteRecord:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _deleteButton;
}

- (UIButton *)playButton{
    if(!_playButton){
        _playButton = [[UIButton alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width/2-50, 370, 100, 30)];
        [_playButton setTitle:@"本地播放" forState:UIControlStateNormal];
        [_playButton setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        _playButton.layer.borderWidth = 1.0;
        _playButton.layer.borderColor = [UIColor purpleColor].CGColor;
        [_playButton addTarget:self action:@selector(playRecord:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _playButton;
}

- (UIButton *)playOnlineButton{
    if(!_playOnlineButton){
        _playOnlineButton = [[UIButton alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width/2-50, 420, 100, 30)];
        [_playOnlineButton setTitle:@"云端播放" forState:UIControlStateNormal];
        [_playOnlineButton setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        _playOnlineButton.layer.borderWidth = 1.0;
        _playOnlineButton.layer.borderColor = [UIColor purpleColor].CGColor;
        [_playOnlineButton addTarget:self action:@selector(playOnlineRecord:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _playOnlineButton;
}

- (void)startRecord:(UIButton *)sender{
      _timeCount = 0;
    [self startRecord];
}

- (void)stopRecord:(UIButton *)sender{
    [self stopRecord];
}

- (void)deleteRecord:(UIButton *)sender{
    if([[NSFileManager defaultManager] fileExistsAtPath:_Path]){
        BOOL success = [[NSFileManager defaultManager] removeItemAtPath:_Path error:nil];
        if(success){
            NSLog(@"删除成功！");
        }else{
            NSLog(@"删除失败！");
        }
        self.recordTimeLabel.text = @"00:00:00";
    }
}

- (void)playRecord:(UIButton *)sender{
    if(_url){
     _play = [[AVAudioPlayer alloc] initWithContentsOfURL:_url  error:nil];
     _play.delegate = self;
     _play.volume = 1;
    [_play prepareToPlay];
     [_play play];
    }
}

- (void)playOnlineRecord:(UIButton *)sender{
    //网络地址
    NSString *Path = @"www.xxxxxx.pcm";
    NSURL *url = [NSURL URLWithString:Path];
    //转化成NSData
    NSData *data = [NSData dataWithContentsOfURL:url];
    //使用initWithData方法
    _play = [[AVAudioPlayer alloc] initWithData:data error:nil];
    _play.delegate = self;
    _play.volume = 1;
    [_play prepareToPlay];
    [_play play];
}

// 开始录音
- (void)startRecord{
    _Path = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"recordFile.pcm"];
    _url = [NSURL URLWithString:_Path];
    NSDictionary *configDic = @{
                                //编码格式
                                AVFormatIDKey:@(kAudioFormatLinearPCM),
                                //采样率
                                AVSampleRateKey:@(11025.0),
                                //通道数
                                AVNumberOfChannelsKey:@(2),
                                //录音质量
                                AVEncoderAudioQualityKey:@(AVAudioQualityHigh)
                                };
    _audioRecorder = [[AVAudioRecorder alloc] initWithURL:_url settings:configDic error:nil];
    //开启音量检测
    _audioRecorder.meteringEnabled = YES;
    _audioRecorder.delegate = self;
    //准备录音
    [self.audioRecorder prepareToRecord];
    [self startVoiceTimer];
    //开始录音
    [self.audioRecorder record];
    
    if (!self.recordTimer) {
        self.recordTimer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(recordTimeUpdate:) userInfo:nil repeats:YES];
    }
}

// 录音音量开启监测
- (void)startVoiceTimer{
    self.voiceTimer = [NSTimer timerWithTimeInterval:0.1 target:self selector:@selector(detectionVoice) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.voiceTimer forMode:NSRunLoopCommonModes];
    [self.voiceTimer setFireDate:[NSDate distantPast]];
}

// 结束录音
- (void)stopRecord{
    if(self.audioRecorder){
        [self.audioRecorder stop];
        [self stopVoiceTimer];
    }
    self.waver.normalizedValue = 0;
}

// 录音音量停止监测
- (void)stopVoiceTimer{
    if(self.voiceTimer){
        [self.voiceTimer setFireDate:[NSDate distantFuture]];
        if([self.voiceTimer isValid])
        {
            [self.voiceTimer invalidate];
        }
        self.voiceTimer = nil;
        NSLog(@"停止监测音量");
    }
    if (self.recordTimer) {
        [self.recordTimer invalidate];
        self.recordTimer = nil;
    }
}

// 录音音量显示
- (void)detectionVoice{
    // 刷新音量数据
    [_audioRecorder updateMeters];
    CGFloat voice = 20 * pow(10,0.05*[self.audioRecorder peakPowerForChannel:0]);
    CGFloat peakVolume = [self.audioRecorder peakPowerForChannel:0];
    NSLog(@"voice : %f",peakVolume);
    // 波形大小随音量
    self.waver.normalizedValue = voice;
}

// 刷新时间显示 和 录音时长
- (void)recordTimeUpdate:(id)sender{
     _timeCount += 1;
    //分秒数
    NSUInteger percentSecond = _timeCount;
    NSUInteger percentSecondValue = percentSecond%100;
    //秒数
    NSUInteger second = percentSecond/100;
    NSUInteger secondValue = second%60;
    //分数
    NSUInteger minute = second/60;
    
    NSString *showString = [NSString stringWithFormat:@"%02lu:%02lu:%02lu",(unsigned long)minute,(unsigned long)secondValue,(unsigned long)percentSecondValue];
    
    self.recordTimeLabel.text = showString;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
